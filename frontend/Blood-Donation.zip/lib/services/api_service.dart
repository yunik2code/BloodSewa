import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'https://de2e9effdb93.ngrok-free.app/api';

  static Future<Map<String, dynamic>> register({
    required String username,
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String bloodGroup,
    required String phone,
    required bool isDonor,
    double? latitude,
    double? longitude,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register/'),
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true',
        },
        body: json.encode({
          'username': username,
          'email': email,
          'password': password,
          'first_name': firstName,
          'last_name': lastName,
          'blood_group': bloodGroup,
          'phone': phone,
          'is_donor': isDonor,
          'latitude': latitude,
          'longitude': longitude,
        }),
      );

      return {
        'success': response.statusCode == 201,
        'data': json.decode(response.body),
        'statusCode': response.statusCode,
      };
    } catch (e) {
      return {
        'success': false,
        'data': {'error': e.toString()},
        'statusCode': 500,
      };
    }
  }

  static Future<Map<String, dynamic>> login(
      String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login/'),
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true',
        },
        body: json.encode({
          'username': username,
          'password': password,
        }),
      );

      return {
        'success': response.statusCode == 200,
        'data': json.decode(response.body),
        'statusCode': response.statusCode,
      };
    } catch (e) {
      return {
        'success': false,
        'data': {'error': e.toString()},
        'statusCode': 500,
      };
    }
  }

  static Future<Map<String, dynamic>> getProfile() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('access_token');

      final response = await http.get(
        Uri.parse('$baseUrl/profile/'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
          'ngrok-skip-browser-warning': 'true',
        },
      );

      return {
        'success': response.statusCode == 200,
        'data': json.decode(response.body),
        'statusCode': response.statusCode,
      };
    } catch (e) {
      return {
        'success': false,
        'data': {'error': e.toString()},
        'statusCode': 500,
      };
    }
  }

  static Future<Map<String, dynamic>> getNearbyDonors({
    required String bloodGroup,
    required double latitude,
    required double longitude,
    double radius = 10.0,
  }) async {
    try {
      final response = await http.get(
        Uri.parse(
            '$baseUrl/donors/?blood_group=$bloodGroup&latitude=$latitude&longitude=$longitude&radius=$radius'),
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true',
        },
      );

      return {
        'success': response.statusCode == 200,
        'data': json.decode(response.body),
        'statusCode': response.statusCode,
      };
    } catch (e) {
      return {
        'success': false,
        'data': {'error': e.toString()},
        'statusCode': 500,
      };
    }
  }
}
